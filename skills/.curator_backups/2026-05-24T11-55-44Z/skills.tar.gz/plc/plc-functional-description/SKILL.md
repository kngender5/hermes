---
name: plc-functional-description
description: Generer en detaljert funksjonsbeskrivelse for et PLC‑styresystem basert på tilgjengelige prosjektdokumenter (I/O‑liste, PLC‑oppsett, programsekvenser, sikkerhetskrets, HMI‑plan, konfigurasjon, FAT‑test, bruksanvisning).
triggers:
  - bruker ber om funksjonsbeskrivelse, programmeringsbeskrivelse, eller lignende dokumentasjon for et PLC‑prosjekt
  - behov for å samle teknisk informasjon til en strukturert, punktvis rapport med begrunnelse for valg
---
# Formål
Denne skillen beskriver hvordan man produserer en komplett, punktvis funksjonsbeskrivelse (på norsk) for et PLC‑basert styresystem, med begrunnelse for alle tekniske valg. Den er ment å brukes når man har tilgjengende kildefiler fra et prosjekt (som typisk genereres i en automatasjonsoppgave) og trenger å skape ett referansedokument for implementering, testing og overlevering.

# Forutsetninger
- Tilgang til følgende filer (kan være i en mappe som `~/Output/Prosjektoppgave/` eller tilsvarende):
  - I/O‑liste (`I_O_liste.txt` eller tilsvarende)
  - PLC‑oppsett‑plan (`PLC_oppsett_plan.txt`)
  - Programsekvenser (`Program_sekvenser.txt`)
  - Sikkerhetskrets‑dokumentasjon (`Sikkerhetskrets_dokumentasjon.txt`)
  - HMI‑utviklingsplan (`HMI_utviklingsplan.txt`)
  - Konfigurationsoppsummering (`Konfigurasjonsoppsummering.txt`)
  - FAT‑testplan (`FAT_testplan.txt`)
  - Bruksanvisning (`Bruksanvisning.txt`)
- Evt. tilleggsmateriell som blokkdiagram, P&ID, eller hardware‑spesifikasjoner (ikke obligatorisk).

# Arbeidsflyt (punktvis)

1. **Samle og lese kildefiler**
   - Les hver fil sekvensielt for å skape deg et overblikk over systemet.
   - Merk ned følgende nøkkelopplysninger:
     * I/O‑adresser og beskrivelser (sensorer, aktuatorer)
     * Datablokker (DB‑navn, variabler, datatyper, formål)
     * Sekvenssteg/trinn (tilstandsmaskin, handlinger per trinn, betingelser for overgang)
     * Sikkerhetskrets (nødstopp, dør-/gjersensorer, nullstillingslogikk, alarmhåndtering)
     * HMI‑struktur (taggkobling, skjermer, alarmvisning, logging)
     * Testkrav (FAT) og brukerprosedyrer (bruksanvisning)

2. **Bestem dokumentstruktur**
   En typisk funksjonsbeskrivelse inneholder følgende seksjoner (juster etter prosjektets kompleksitet):
   1. Innledning og formål
   2. Systemoversikt (overordnet funksjon, blokkdiagram beskrivelse)
   3. Maskinvare og I/O (detaljert I/O‑liste, adressefordeling, signaltyper)
   4. Programmstruktur (PLC‑platform, språk, datablokker, sekvensstyring)
   5. Sikkerhetskrets (fysisk tilkobling, PLC‑logikk, alarmhåndtering)
   6. HMI‑kobling (kommunikasjon, taggstruktur, skjermer, logging)
   7. Testing og overlevering (FAT‑plan, bruksanvisning, vedlikehold)
   8. Konklusjon

3. **Skriv seksjon for seksjon**
   - For hver seksjon, sammendrag de relevante fakta fra kilfilene.
   - Gi en kort begrunnelse for hvert teknisk valg (f.eks. hvorfor en viss I/O‑adresse ble valgt, hvorfor en viss datatype ble brukt, hvorfor en viss sekvenslogikk ble valgt).
   - Hold tekst på norsk, teknisk presis, og unngå unødvendig flott tekst.
   - Nummerer underpunkter dersom du vil gjøre det lettere å følge (f.eks. 3.1 Datablokker, 3.2 Sekvensstyring).

4. **Formater og lever**
   - Lagre dokumentet som ett ren tekstfil (`.txt`) eller markdown (`.md`) avhengig av krav.
   - Bruk overskrifter (`#`, `##`, `###`) for tydelig hierarki.
   - Sett inn kodeeksempler eller utdrag fra kilfilene dersom det gjør beskrivelsen klarere (f.eks. ett eksempel på hvordan en variabel erklæres i TIA Portal).
   - Kontroller at alle viktige variabler, I/O‑adresser og sekvenssteg er nämnt minst én gang.

5. **Kvalitetssjekk**
   - Les dokumentet igjennom og verifiser at:
     * Alle kildefiler er representert.
     * Hvert teknisk valg har en tilhørende begrunnelse.
     * Språket er gjennomgående norsk.
     * Dokumentet er lett å lese for både tekniker og beslutningstaker.
   - Eventuelt be en kollega eller bruker om å lese gjennom for å oppdage tvetydigheter eller mangler.

# Eksempel på utdatastruktur (punktvis)

```
Funksjonsbeskrivelse – Styresystem for Varemottak og Lager
=========================================================

1. Systemoversikt
   - Anlegget mottar paller ... (begrunnelse: valgt basert på produktfordeling og plassbegrensning)
   ...

2. Maskinvare (I/O)
   - Digital input:
       I0.0 – Start‑knapp ... (begrunnelse: plassert på betjeningspanelet for enkel tilgang)
       ...
   - Digital output:
       Q0.0 – Transportelement innlasting → lift ... (begrunnelse: styrer hovedtransporten til lift)
       ...
   ...

3. Programmstruktur
   3.1 Datablokker
       DB1 – Esketelling
           TotalEsker (INT) – totalt antall mottatte esker ... (begrunnelse: nødvendig for CSV‑logging og statistikk)
           ...
   3.2 Sekvensstyring (tilstandsmaskin)
       Trin 0 – INITIALISERING
           Handling: nullstill outputs ... (begrunnelse: sikrer kjent starttilstand)
           Betingelse for neste trinn: start‑knapp trykket og ingen aktive alarmer ...
       ...

4. Sikkerhetskrets
   - Fysisk tilkobling: alle nødstopp og dør-/gjersensorer (NC) seriekoblet til I0.2 ... (begrunnelse: fail‑safe, én felles avbruddssignal)
   - PLC‑logikk: Safety_OK = NOT(I0.2); alle kritiske outputs AND‑es med Safety_OK ... (begrunnelse: umiddelbart stopp ved feil)
   ...

5. HMI – WinCC Flexible Runtime
   - Kommunikasjon: PROFINET mellom S7‑1500 og PC ... (begrunnelse: standard i TIA‑miljøet, rask og pålitelig)
   - Taggkobling: TotalEsker (DB1) → HMI‑tagg `TotalEsker` ... (begrunnelse: enkel tilgang for operatøren)
   ...

6. Testing og FAT
   - Se FAT_testplan.txt for detaljerte prosedyrer ... (begrunnelse: sikrer at alle krav er verifisert før levering)
   ...

7. Konklusjon
   - Dokumentet beskriver ... (begrunnelse: oppsummerer at løsningen møter alle spesifikasjoner)
```

# Pitfalls og tips
- **Ikke kopier råtekst fra kilfilene direkte** – omformuler og legg til begrunnelse; råkopi gir begrunnelse dokumentet lite verdi.
- **Unngå for teknisk dyp nivå i seksjon 2** hvis målgruppen inkluderer beslutningstakere; flytt detaljer til et vedlegg dersom nødvendig.
- **Sjekk at alle variabelnavn og I/O‑adresser stemmer** med de faktiske adressene i TIA‑prosjektet; feil her fører til feilkobling under testing.
- **Hold seksjonene korte og fokusert** – hver seksjon bør ikke overstige 300‑400 ord unntatt vedlegg.
- **Bruk konsistente termer** (f.eks. alltid „nødstopp” ikke „nødstans” eller „nødstoppbryter”) for å unngå forvirring.

# Verifisering
Et rask måte å sjekke at dokumentet er komplett er å gå gjennom hver kilfil og stille spørsmålet: „Hvor er informasjonen fra denne filen representert i beskrivelsen, og er valgene begrunnet?“ Hvis svaret er nei for noen punkt, legg til eller revider tilsvarende seksjon.

# Relaterte ferdigheter
- `plc-tia-portal-planning` – for å lage det overordnede PLC‑oppsettet før funksjonsbeskrivelsen skrives.
- `hmi-utviklingsplan` – for å skape detaljerte HMI‑specs som kan refereres til i seksjon 6.
- `fatt-testplan` – for å sikre at testkravene er refleksert i seksjon 6.

# Notat
Denne skillen er ment å være gjenbrukbar på tvers av flere PLC‑prosjekt. Juster filnavn og seksjoner etter behov for det aktuelle prosjektet.