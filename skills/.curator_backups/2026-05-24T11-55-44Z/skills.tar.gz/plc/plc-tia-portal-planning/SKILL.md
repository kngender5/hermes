---
name: plc-tia-portal-planning
description: Generate PLC program plan for Siemens TIA Portal (LAD/FBD) based on project specification, including I/O list, variable/DB design, sequence control, safety circuit documentation, HMI development plan, and data logging.
version: 0.1.0
category: plc
---

# PLC Program Planning – Siemens TIA Portal (LAD/FBD)

This skill provides a structured approach to creating a complete PLC program plan for a typical automation project (e.g., warehouse/pallet handling) using Siemens TIA Portal v19+ with Ladder Diagram (LAD) and/or Function Block Diagram (FBD). It covers all deliverables: hardware configuration, variable and data block design, control sequence (state machine), safety functions, HMI concept (WinCC Flexible Runtime), data logging to CSV, and documentation.

## When to Use
- Starting a new PLC programming project where the specification describes inputs/outputs, sequencing, safety, HMI, and logging requirements.
- When you need to produce a detailed plan before implementation in TIA Portal.
- As a checklist to ensure nothing is omitted.

## Procedure

### 1. Understand the Specification
- Read the project description (PDF, text, or images).
- Extract key functions: sensor/actuator list, sequence of operations, safety requirements (emergency stop, area sensors, alarm, reset), HMI screens, data to log.
- If the source is a scanned PDF, apply OCR (e.g., `tesseract` with language `nor+eng`) to obtain editable text.

### 2. Create the TIA Portal Project
- **Project Name**: Choose a descriptive name (e.g., `Varemottak_Lager_AUT23`).
- **PLC Model**: Select the appropriate S7‑1500 (or other) model available in your lab.
- **Programming Language**: Set to LAD and/or FBD (only these are allowed per spec).
- **Tip**: Use a consistent naming convention for blocks (FC/FB, DB, UDT).

### 3. Hardware Configuration (HW Config)
- Add modules matching the I/O list:
  - Digital inputs for start/stop, emergency stop, reset, emitter sensor, size detection, door/area sensors, level sensors, pallet detection at lift in/out, removal sensors.
  - Digital outputs for transport belts, lift up/down, alarm lamp, run lamp, tower lights (green/red per section), and any spare.
- Addressing: Use the byte.bit format (e.g., `%I0.0`, `%Q0.0`) and note that addresses can be adjusted later.
- Configure PROFINET interface for HMI (WinCC Flexible Runtime) connection.

### 4. Define Variables and Data Blocks (DB)
Create the following DBs (numbers are suggestions; adjust as needed):

| DB | Purpose | Variables (Name, Type, Description) |
|----|---------|--------------------------------------|
| DB1 | **Counter Register** | `TotalEsker` (INT) – total pallets received<br>`Esker_Liten` (INT) – pallets small size<br>`Esker_Medium` (INT) – pallets medium size<br>`Esker_Stor` (INT) – pallets large size |
| DB2 | **Alarm Register** | `Safety_OK` (BOOL) – 1 when no E‑stop or door sensor active<br>`Alarm_Safety` (BOOL) – aggregated safety alarm<br>`Alarm_EmitterFault` (BOOL) – optional emitter fault<br>`Alarm_HeisTimeout` (BOOL) – lift timeout<br>`Alarm_SizeError` (BOOL) – invalid/multiple size signals<br>`AlarmBit_[0‑15]` (BOOL) – individual alarm bits for detailed HMI |
| DB3 | **HMI & Control Variables** | `Cmd_StartAnlegg` (BOOL) – HMI start push‑button (momentary)<br>`Cmd_StopAnlegg` (BOOL) – HMI stop push‑button<br>`Cmd_ResetSikkerhet` (BOOL) – HMI reset push‑button<br>`Cmd_Emitter_OnOff` (BOOL) – HMI emitter on/off<br>`Cmd_TømEtasje[3]` (BOOL) – manual empty per level<br>`SeqStep` (INT) – current sequence step (0‑11, 99 for alarm)<br>`TargetLevel` (INT) – destination level (1=bottom,2=middle,3=top) based on size<br>`Pall_Count_Etasje[3]` (INT) – current pallets in each level<br>`Heis_Niva` (INT) – lift level (1‑3) from sensors<br>`CycleDone` (BOOL) – one‑scan pulse after a full pallet cycle |
| DB4 (optional) | **Pallet Info (UDT)** | Define UDT `PallInfo` with `Size` (INT: 0=small,1=medium,2=large), `Destination` (INT: 1‑3), `Timestamp` (DATE_AND_TIME). Then an array of this UDT for traceability. |

- Add meaningful comments (in Norwegian) to each variable.
- Use UDTs where appropriate for structured data.

### 5. Develop the Control Sequence (State Machine)
Implement the main sequence as a state machine using an integer variable (`SeqStep`) or a block‑structure with jumps. Typical steps:

| SeqStep | Description | Key Actions | Exit Condition |
|---------|-------------|-------------|----------------|
| 0 | **Initialization** | Reset outputs, counters; move lift to home (bottom); wait for normal sensor state | No alarm AND Start button = 1 |
| 1 | **Wait for Infeed** | Hold infeed belt off; wait for emitter sensor (pallet in) | Emitter sensor = 1 |
| 2 | **Detect Size** | Read size inputs (small/medium/big); set `TargetLevel` accordingly (small→top, middle→middle, big→bottom) | Exactly one size signal active |
| 3 | **Transport to Lift** | Start infeed belt → lift (`Q0.0 = 1`) | Pallet detected at lift‑in (`I1.4 = 1`) |
| 4 | **Wait Lift‑In** | Stop infeed belt; wait for pallet at lift‑in | Pallet lift‑in confirmed (with debounce) |
| 5 | **Lift Travel to Target** | Determine direction (up/down) based on current level vs `TargetLevel`; start lift (`Q0.1` or `Q0.2`) | Level sensor for `TargetLevel` = 1 |
| 6 | **Wait Lift Position** | Stop lift; wait for level sensor stable (≥50‑100 ms) | Level sensor = 1 (stable) |
| 7 | **Transport Out from Lift** | Select correct outbound belt per `TargetLevel` (`Q0.3`‑`Q0.5`) and start it | Pallet detected at lift‑out for that level (`I1.5‑I1.7 = 1`) |
| 8 | **Wait Outfeed Complete** | Stop outbound belt; wait until pallet has left lift area and is on the storage belt (`I1.5‑I1.7 = 1` AND removal sensor = 0) | Pallet outfeed confirmed |
| 9 | **Wait for Removal (Forklift)** | Keep outbound belt running to allow pallet to move forward; wait for removal sensor (`I2.0‑I2.2 = 1`) | Removal sensor = 1 (pallet taken) |
| 10 | **Count & Log** | Increment `TotalEsker` and appropriate size counter; set `CycleDone` = 1 (one scan) | Removal sensor = 1 |
| 11 | **Reset Outbound Belt & Prepare Next Cycle** | Stop outbound belt; optionally jog belt back; return lift to home (bottom); wait until all transport belts empty and lift at home | No pallets on any belt AND lift at home → go to step 0 |
| 99 | **Emergency Stop / Alarm** | Set all safety‑critical outputs to 0; activate alarm lamp and relevant tower lights red; await E‑stop release AND reset button press (and all other alarms inactive) | E‑stop released AND reset pressed → go to step 0 |

- Implement each step in LAD/FBD using contacts, coils, timers (TON, TOF, TP) for debounce and timeouts, and counters if desired.
- Use modular blocks (FC/FB) for each step to improve readability.
- Add comments in Norwegian on every network or block.

### 6. Safety Circuit Logic
- Wire all emergency stop buttons and door/area sensors as normally‑closed (NC) series to a single PLC input (e.g., `I0.2`).  
- In the PLC, derive `Safety_OK = NOT EStopOrDoorActive`.  
- Use `Safety_OK` to gate all motion‑critical outputs (transport belts, lift, outbound belts) via AND logic.
- Alarm handling:
  - Set internal alarm bits (e.g., `Alarm_Safety`) when `Safety_OK = 0`.
  - Map each safety source to distinct alarm bits if zone‑specific indication is desired (e.g., separate door sensor alarm).
  - Drive HMI alarm lamp (`Q0.6`) and tower lights (red) from these bits.
  - Provide reset logic: reset only allowed when `Safety_OK = 1` and reset button pressed (one‑scan pulse).
- Document fail‑safe behavior: loss of power or broken wire → input = 0 → safe state.

### 7. HMI Concept (WinCC Flexible Runtime)
- **Screens**:
  1. **Main Overview** – Graphic layout of conveyors, lift, levels; indicators for run/lamp status; push‑buttons for Start, Stop, Reset, Emitter On/Off; display of pallet count per level and total.
  2. **Alarm Screen** – List of active alarms with descriptions and timestamps; optional acknowledgement and reset buttons.
  3. **Alarm Log Screen** – Historical alarm list with start/end times and duration; export to CSV.
  4. **(Optional) Settings Screen** – Password‑protected for changing parameters (e.g., max pallets per level, timeouts).
- **Tags**: Link HMI tags to the PLC DB variables defined above (especially those in DB3 for commands and indicators, DB1 for counters, DB2 for alarms).
- **Language**: All on‑screen text, button labels, tooltips, and comments in Norwegian (requirement).
- **Update Rate**: Aim for 200 ms refresh for responsive indication.
- **Navigation**: Provide consistent buttons or menu to switch between screens.
- **Data Logging to CSV**:
  - Use a WinCC Flexible Runtime script (VBScript) that reads `TotalEsker`, `Esker_Liten`, `Esker_Medium`, `Esker_Stor` from the PLC every second (or on `CycleDone` pulse).
  - Write a line to a CSV file: `DD.MM.YYYY HH:MM:SS,TotalEsker,Esker_Liten,Esker_Medium,Esker_Stor`.
  - Optionally create a new file each day (`EskerLogg_YYYYMMDD.csv`) for easy archiving.
  - Provide an HMI button to export the current log or view it.

### 8. Documentation & Comments
- Ensure every block, network, and variable has a descriptive comment in Norwegian.
- Create a functional description document that explains each step of the sequence, safety functions, and HMI interaction.
- Prepare an operating manual covering start‑up, normal operation, emergency stop handling, reset procedure, and maintenance notes.
- Include a test plan for Factory Acceptance Test (FAT) using the supplied digital twin: verify sequence, size routing, safety functions, alarm indications, and counter logging.

### 9. Testing and FAT
- Download the program to the PLC (or use PLCSIM) and connect HMI.
- Run simulations with the digital twin to validate:
  - Correct pallet routing according to size.
  - Proper lift movement and stopping at levels.
  - Emergency stop and door sensor stop all motion and trigger alarms.
  - Reset only works when all safety inputs are inactive.
  - Counters increment correctly and CSV log is written.
- Document test results and any deviations.

## Tips & Pitfalls
- **Tip**: Use IEC timers (TON, TOF, TP) from the *Extended Instructions* library for reliable debounce and timeouts rather than legacy S5 timers.
- **Tip**: Keep the sequence modular; each major step as its own FB with clear inputs/outputs simplifies testing and troubleshooting.
- **Tip**: In the I/O list, consider adding summary statistics at the end (total inputs/outputs including reservations) for quick reference.
- **Tip**: For HMI development in WinCC Flexible Runtime, aim for a 200ms update rate for responsive indication and include consistent navigation buttons between screens.
- **Tip**: When implementing data logging to CSV, use a WinCC script that reads counter variables from the PLC-DB on each pallet cycle (via a CycleDone flag) or every second, and write timestamped lines to a daily file (e.g., EskerLogg_YYYYMMDD.csv).
- **Tip**: In safety circuit documentation, explicitly describe how to identify which safety function triggered (e.g., separate alarm bits for E-stop vs. door sensors per zone) and consider logging timestamps for alarm history.
- **Tip**: For HTML-based HMI mockups, add `<meta name="viewport" content="width=device-width, initial-scale=1.0">` for responsiveness, `role="alert"` on alarm banners for accessibility, and explicit `type="button"` on buttons to prevent accidental form submission.
- **Pitfall**: Do not wire emergency stop or door sensors in parallel; series‑NC wiring ensures any open contact breaks the safety circuit (fail‑safe).
- **Pitfall**: Avoid using the same input for both safety and normal control without proper gating; always gate motion outputs with `Safety_OK`.
- **Pitfall**: When using OCR on scanned PDFs, verify the output; Norwegian characters (æ, ø, å) may need the `nor` language pack for tesseract.
- **Pitfall**: In sequence control, ensure that lift movement to home position is properly interlocked (e.g., wait for level sensor confirmation) to prevent starting a new cycle while lift is still moving.

## References
- Siemens TIA Portal Help: *Ladder Logic (LAD) – Basic Instructions*
- Siemens TIA Portal Help: *Function Block Diagram (FBD) – Extended Instructions*
- Siemens TIA Portal Help: *Using IEC Timers and Counters*
- Siemens TIA Portal Help: *Creating and Calling Function Blocks (FC/FB)*
- Siemens TIA Portal Help: *Managing Data Blocks (DB) for Global Variables*

---
You can now use this skill to guide the creation of a full PLC program plan for similar projects.