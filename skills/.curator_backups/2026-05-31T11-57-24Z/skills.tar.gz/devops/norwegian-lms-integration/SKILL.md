---
name: norwegian-lms-integration
description: "Access Norwegian LMS (Canvas/Panopto) via Feide SSO. Download course materials, recordings, and handle authentication flows for Norwegian educational institutions. Covers Canvas API, Panopto API, Feide SSO org selection, and embedded caption extraction."
---

# Norwegian LMS Integration

Access Canvas LMS and Panopto video systems used by Norwegian schools (Fagskolen, universities, etc.) that authenticate via Feide SSO.

## Prerequisites

```bash
pip install canvasapi requests playwright playwright-stealth --break-system-packages
# System chromium (Ubuntu 26+): /usr/bin/chromium-browser
```

Store credentials in `~/.hermes/.env`:
```
CANVAS_BASE_URL=https://<school>.instructure.com/
CANVAS_API_KEY=<from Canvas Settings → Approved Integrations>
CANVAS_USER=<Feide username, e.g. user@stud.school.no>
CANVAS_PASS=<Feide password>
```

## Canvas API

**Read-only access** (courses, assignments, files listing):
```python
from canvasapi import Canvas
canvas = Canvas(CANVAS_BASE_URL, CANVAS_API_KEY)
user = canvas.get_current_user()
courses = list(user.get_courses(enrollment_state="active"))
```

**Note:** Files API returns 403 for many courses due to Canvas permissions. Use browser automation for file downloads.

**CLI tool** — `scripts/canvas` provides: `canvas courses`, `canvas assignments`, `canvas files`, `canvas download`, `canvas syllabus`, `canvas calendar`, `canvas grades`, `canvas announce`. Supports `--skip ID,ID` and `--only ID,ID` flags for selective downloads.

## Panopto Video Download

### Feide SSO Authentication Flow (Playwright)

```
1. Navigate to video → redirects to Panopto login
2. Click "Sign in" → redirects to Feide SSO
3. Feide org selector: TYPE prefix (e.g. "tr") in the search/typeahead field
   (#org_selector_filter, placeholder "Search or choose from the list")
   → This is NOT a plain dropdown; it's a typeahead search
4. Click the LI.orglist_item via JS:
   document.querySelectorAll('li.orglist_item') → find .orglist_name textContent match
5. Click Continue
6. Fill Feide credentials (input[type='text'] or #username, input#password) → submit
7. Canvas OAuth confirm page → click OK/Ja/Godta/Allow button
```

**Critical:** The org selector requires **typing** in a search field first. The full org list is not visible until you type a prefix. Use `page.evaluate()` to click the correct `li.orglist_item` by matching `.orglist_name` textContent.

**Pitfall — `.fill()` does NOT trigger the typeahead filter.** The Feide org selector uses a custom typeahead component that only responds to keyboard events, not to Playwright's `.fill()` method. You MUST use `page.keyboard.type("tr", delay=50)` to filter the list. After typing, wait 2-3 seconds for the filtered list to render, then use `page.evaluate()` to click the matching `li.orglist_item`.

**Pitfall — headed Playwright on WSL2.** When launching a headed browser (headless=False) on WSL2, you MUST set `DISPLAY=:0` in the environment. Without this, Chromium fails with "Missing X server or $DISPLAY". Set it via `os.environ["DISPLAY"] = ":0"` before launching Playwright, or run the script with `DISPLAY=:0 python3 script.py`.

### DeliveryInfo API

```python
delivery_url = f"{PANOPTO_BASE}/Panopto/Pages/Viewer/DeliveryInfo.aspx?deliveryId={video_id}&responseType=json"
r = session.get(delivery_url, cookies=cookies)
data = r.json()

# Direct MP4 (preferred) — PodcastStreams
stream_url = data["Delivery"]["PodcastStreams"][0]["StreamUrl"]

# Fallback: HLS stream — Streams
if not stream_url:
    stream_url = data["Delivery"]["Streams"][0]["StreamUrl"]
    # ffmpeg -i <m3u8_url> -c copy -bsf:a aac_adtstoasc output.mp4
```

**Note:** `DownloadUrl` at top level is often null. Use `PodcastStreams[0].StreamUrl` instead.

## Embedded Caption Extraction

Norwegian Panopto recordings often have embedded `mov_text` subtitles (language: `nor`):

```bash
# Check for subtitle streams
ffprobe -v quiet -print_format json -show_streams video.mp4 | jq '.streams[] | select(.codec_type=="subtitle")'

# Extract to SRT
ffmpeg -y -i video.mp4 -map 0:<sub_index> -c:s srt output.srt

# Clean HTML font tags from SRT
sed -i 's/<font[^>]*>//g; s/<\/font>//g' output.srt
```

For videos without embedded captions:
```bash
whisper-ctranslate2 --language no --model large-v3 --output_format srt video.mp4
```

**Pitfall — watermark interference:** Classroom recordings (e.g., AUT23 Ekom) often have burned-in presenter name watermarks ("Teksting av Nicolai Winther"). Whisper transcribes the watermark instead of speech, producing useless output. Web recordings (WEB prefix) don't have this issue. Check first few minutes of whisper output before trusting it.

**GPU setup:** Requires `libcublas12` and `LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu`:
```bash
sudo apt-get install -y libcublas12
LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH whisper-ctranslate2 ...
```

## Reference Files

- `references/panopto_download.py` — Complete download script with Feide SSO, DeliveryInfo API, caption extraction, and whisper fallback
- `references/canvas_cli.py` — Canvas CLI tool for course/assignment/file management
- `references/canvas_api_patterns.md` — Practical API patterns: module items for file discovery, download techniques, course structure