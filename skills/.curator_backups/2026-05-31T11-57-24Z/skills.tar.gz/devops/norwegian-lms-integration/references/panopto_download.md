Complete Panopto video download script for Norwegian LMS via Feide SSO.

Flow:
1. Open video page → Panopto login → click "Sign in"
2. Feide org selector: type prefix in #org_selector_filter (typeahead search)
3. Click matching li.orglist_item via JS evaluate
4. Click Continue → fill credentials → submit
5. Canvas OAuth confirm → click OK/Ja/Godta
6. Extract Playwright session cookies
7. Call DeliveryInfo API: /Panopto/Pages/Viewer/DeliveryInfo.aspx?deliveryId=UUID&responseType=json
8. Get MP4 from data.Delivery.PodcastStreams[0].StreamUrl (NOT top-level DownloadUrl which is often null)
9. For HLS fallback: data.Delivery.Streams[0].StreamUrl → ffmpeg -i URL -c copy -bsf:a aac_adtstoasc out.mp4
10. Extract embedded captions: ffprobe for subtitle streams → ffmpeg -map 0:idx -c:s srt
11. Whisper fallback for videos without embedded captions

Key pitfalls:
- Org selector is typeahead, NOT a dropdown — must type to filter
- Use page.evaluate() to click li.orglist_item by .orglist_name textContent match
- DownloadUrl top-level field is null; use PodcastStreams[0].StreamUrl
- Ubuntu 26+ needs system chromium: executable_path="/usr/bin/chromium-browser"
- Canvas OAuth confirm page has OK/Ja/Godta button (varies by institution)

Source: ~/projects/study-workbench/scripts/canvas_panopto_download.py
