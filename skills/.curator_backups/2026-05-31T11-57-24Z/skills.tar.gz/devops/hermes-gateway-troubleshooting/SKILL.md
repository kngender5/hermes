---
name: hermes-gateway-troubleshooting
description: "Troubleshoot and fix Hermes gateway platform connections — Discord, Telegram, Slack, and other messaging platforms. Covers token configuration, allowlists, connection failures, and platform-specific quirks."
metadata:
  hermes:
    tags: [hermes, gateway, discord, telegram, slack, troubleshooting, configuration]
---

# Hermes Gateway Troubleshooting

Diagnose and fix gateway connection issues for messaging platforms and related services.

## Quick Diagnosis

```bash
hermes gateway status          # Check if gateway is running
hermes gateway run             # Start in foreground to see errors
```

If the gateway is running but a platform isn't connecting, check the process output:

```bash
hermes gateway run > /tmp/hermes-gateway.log 2>&1 &
sleep 15
cat /tmp/hermes-gateway.log
```

Look for lines containing `[PlatformName]`, `failed to connect`, `No bot token`, or `Unauthorized user`.

## Platform Token Configuration

### Critical: Tokens in .env vs config.yaml

Many platform adapters read credentials from `~/.hermes/.env` (or `~/.hermes/.env`),
**NOT** from `config.yaml`. Even if a token appears in `config.yaml` under the platform section, the adapter may ignore it.

**Always set tokens in BOTH places:**

```bash
# config.yaml — structural metadata (application_id, user_id, enabled, etc.)
hermes config set discord.token YOUR_TOKEN

# .env — actual secrets the adapters read at runtime
echo "DISCORD_BOT_TOKEN=YOUR_TOKEN" >> ~/.hermes/.env
```

### Platform-Specific .env Variables

| Platform | .env Variable | config.yaml Key |
|----------|--------------|-----------------|
| Discord | `DISCORD_BOT_TOKEN` | `discord.token` |
| Telegram | `TELEGRAM_BOT_TOKEN` | `telegram.token` |
| Slack | `SLACK_BOT_TOKEN` | `slack.token` |

### Deprecated .env Variables

Hermes warns about `TERMINAL_CWD` in `.env`. Unset from shell environment:

```bash
unset TERMINAL_CWD
```

Also remove any active (uncommented) `TERMINAL_CWD=` lines from `~/.hermes/.env`.

## Gateway Allowlist Configuration

By default, the gateway denies all unauthorized users. You must configure allowlists:

### Per-Platform Allowlists (Recommended)

Add to `~/.hermes/.env`:

```bash
DISCORD_ALLOWED_USERS=your_discord_user_id
TELEGRAM_ALLOWED_USERS=your_telegram_user_id
SLACK_ALLOWED_USERS=your_slack_user_id
```

### Open Access (Development Only)

```bash
GATEWAY_ALLOW_ALL_USERS=true
```

⚠️ Never use `GATEWAY_ALLOW_ALL_USERS=true` in production — anyone with the bot link can trigger your agent.

## Discordspecific Quirks

### Application ID vs User ID

- `application_id` — your Discord application's client ID (found in Developer Portal → General Information)
- `user_id` — your own Discord user ID (for allowlist and identification)
- Both go in `config.yaml` under `discord:`

### Discord Developer Portal Settings

Ensure these are enabled under Bot → Privileged Gateway Intents:
- **Message Content Intent** — required for the bot to read message content
- **Server Members Intent** — required for member-related features

### Token Regeneration

If a token is exposed in chat or logs, regenerate it immediately in the Discord Developer Portal → Bot → Reset Token. Then update both `config.yaml` and `.env`.

## Common Errors

### `[Discord] No bot token configured`
Token not found in environment. Add `DISCORD_BOT_TOKEN` to `.env` and restart gateway.

### `Unauthorized user: <id> (<name>) on discord`
User not in allowlist. Add their ID to `DISCORD_ALLOWED_USERS` in `.env`.

### `Gateway started with no connected platforms`
All platforms failed to connect. Check individual platform errors above. Common causes:
- Missing tokens in `.env`
- Invalid/expired tokens
- Network connectivity issues

### WARNING: `No user allowlists configured`
Gateway is running but no allowlists are set. Set per-platform `ALLOWED_USERS` in `.env`.

## Gateway Process Management

### Clean Restart

```bash
# Kill existing gateway processes
pkill -f "hermes gateway"    # or kill individual PIDs

# Wait for clean exit
sleep 2

# Start fresh with logging
hermes gateway run > /tmp/hermes-gateway.log 2>&1 &
```

### Running Persistently (WSL)

```bash
# tmux (recommended for WSL)
tmux new -s hermes 'hermes gateway run'

# nohup (alternative)
nohup hermes gateway run > /tmp/hermes-gateway.log 2>&1 &
```

### Checking for Duplicate Processes

```bash
hermes gateway status
# If multiple PIDs shown, kill the stale ones individually
kill <stale_pid>
```
