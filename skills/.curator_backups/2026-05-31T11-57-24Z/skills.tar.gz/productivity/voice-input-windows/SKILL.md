---
name: voice-input-windows
description: Set up voice input on Windows — global hotkeys for push-to-talk and always-on ASR using Python keyboard+sounddevice+faster-whisper. Covers both WSL-bridge and Windows-native approaches.
triggers:
  - voice input
  - speech to text
  - voice hotkey
  - whisper hotkey
  - push to talk
  - always on asr
  - voice transcription
  - global hotkey
  - numpad voice
---

# Voice Input on Windows

Two architectures for voice input from a Windows microphone.

## Architecture A — WSL Bridge

Record on Windows via ffmpeg dshow, transcribe in WSL with faster-whisper (CUDA).

**Script:** `~/bin/voice-input` (bash)

```
voice-input              # record 10s, auto-detect language
voice-input -s 15        # record 15 seconds
voice-input -l no        # force Norwegian
voice-input -l en        # force English
voice-input -m tiny      # model size
```

**Components:**
- `~/bin/voice-input` — orchestrator (bash)
- `~/bin/voice_transcribe.py` — Whisper transcription (Python, WSL, CUDA)
- `C:\Users\<user>\Documents\voice-record.ps1` — Windows recorder (PowerShell + ffmpeg)

## Architecture B — Windows Native Hotkey Daemon

All-in-one Python on Windows. Global hotkeys for PTT and always-on ASR.

**Script:** `C:\Users\<user>\bin\voice_hotkey.py`

```
pythonw C:\Users\<user>\bin\voice_hotkey.py    # background
python  C:\Users\<user>\bin\voice_hotkey.py    # with console
```

**Dependencies (Windows Python):**
```
pip install keyboard faster-whisper sounddevice numpy pyperclip win10toast
```

### Default Hotkeys

| Hotkey | Action |
|--------|--------|
| Left + Numpad0 | Push-to-talk (15s record → transcribe → type) |
| Left + Numpad3 | Toggle always-on ASR |
| Left + Numpad4 | Language cycle: auto → EN → auto → ... |
| Left + Numpad6 | Language cycle: auto → NB → auto → ... |

### Log File

`C:\Users\<user>\Documents\voice_hotkey.log` — all activity, survives crashes.

## Critical Pitfalls

### keyboard module key names
Use `'num 0'` (with space), NOT `'numpad0'` or `'numpad 0'`:
```python
kb.add_hotkey('left+num 0', callback)   # CORRECT
kb.add_hotkey('left+numpad0', callback) # FAILS
```
Verified names: `num 0`–`num 9`, `left`, `right`.

### kb.wait() broken on Windows
`kb.wait()` returns immediately on Windows PowerShell. Use a blocking loop instead:
```python
while True:
    time.sleep(1)
```

### CUDA fallback probe
`WhisperModel()` constructor doesn't allocate GPU memory — lazy load. Constructor succeeds but `transcribe()` fails with `cublas64_12.dll not found`. Must probe with an actual transcription:
```python
tmp = create_silent_wav(1)  # 1s silence
m = WhisperModel(MODEL, device='cuda', compute_type='float16')
segs, _ = m.transcribe(tmp, beam_size=1, vad_filter=False)
list(segs)  # force iteration — this triggers CUDA init
```
If that fails, fall back to CPU `int8`.

### Re-entrant hotkey guard
Hotkey callbacks fire in a thread. If already recording, ignore duplicate triggers:
```python
_ptt_active = False

def push_to_talk():
    global _ptt_active
    if _ptt_active:
        return
    _ptt_active = True
    try:
        # ... record + transcribe ...
    finally:
        _ptt_active = False
```

### HF symlinks warning on Windows
Set `os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'` before importing huggingface.

### Write files from WSL to Windows
Use `/mnt/c/Users/<user>/path` for writes. PowerShell escaping via WSL `terminal()` is unreliable — write `.ps1` files from WSL and execute via `powershell.exe -File "C:\path\script.ps1"`.

### .pyc cache staleness
When updating scripts written from WSL, Windows Python may cache old `.pyc`. Delete `__pycache__` or use `python -B` flag.

## WSL Python Environment (PEP 668)

System Python on Ubuntu 24.04+ is locked down (externally-managed-environment). `pip install` will fail. Use `uv` to create a venv:

```bash
# One-time setup
cd /tmp && uv venv whisper-env
source whisper-env/bin/activate
uv pip install faster-whisper
```

Use `/tmp/whisper-env/bin/python` to run transcription scripts (survives across sessions in `/tmp` only until reboot — recreate if needed).

Alternative: `uv pip install --break-system-packages` works but is NOT recommended.

## ffmpeg on Windows
Install via winget: `winget install -e --id Gyan.FFmpeg`
After install, refresh PATH in new shells: `$env:Path = [System.Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [System.Environment]::GetEnvironmentVariable('Path','User')`

ffmpeg on Windows supports `dshow` for microphone capture:
```
ffmpeg -y -f dshow -t 10 -i "audio=Microphone Array (Realtek(R) Audio)" -ac 1 -ar 16000 -sample_fmt s16 out.wav
```

## Project Layout

```
C:\Users\<user>\bin\
  voice_hotkey.py          # hotkey daemon (main entry point)
  voice_input.py           # record + transcribe module
C:\Users\<user>\Documents\
  voice_hotkey.log         # runtime log
  voice_hotkey.log.bak     # previous session log (rotated manually)
~/. WSL:
  bin/voice-input          # WSL bridge orchestrator (bash) — see templates/voice-input
  bin/voice_transcribe.py  # Whisper transcription (Python, CUDA) — see templates/voice_transcribe.py
```

## Mic Access in WSL

WSL2 does NOT have direct microphone access. Recording requires:
- **PulseAudio bridge** on Windows (e.g., pulseaudio Windows build, or WSLg)
- **OR** record via PowerShell on Windows (`dshow`) and transcribe in WSL
- Test mic: `arecord -l` (ALSA) or `pactl list sources` (PulseAudio)
- If no mic found, fall back to Architecture A with `voice-record.ps1` on Windows

## Model Selection for Norwegian

**Do NOT use generic `large-v3` for Norwegian** — it performs poorly on Norwegian transcription, especially with mixed Norwegian/English speech. Use a Norwegian-specific model instead:

| Model | Size | Quality | Download |
|-------|------|---------|----------|
| `NbAiLab/nb-whisper-medium` | ~1.5 GB | **Best balance** — fast download, excellent Norwegian | Recommended |
| `NbAiLab/nb-whisper-large` | ~3 GB | Best accuracy but very slow to download (30+ min) | If quality critical |
| `NbAiLab/nb-whisper-small` | ~0.5 GB | Acceptable, fast | Low-resource fallback |

Set `MODEL = "NbAiLab/nb-whisper-medium"` in `voice_transcribe.py`.

## TTS (Text-to-Speech) Notes

**NeuTTS requires a reference audio file** (`jo.wav`) — it is a voice cloning TTS, not zero-shot. The `neutts_samples/` directory must contain a recorded sample of the target voice. If missing, TTS fails with "reference audio not found".

**Recommended alternative for Norwegian TTS:** `edge-tts` (free, no voice cloning needed):
```bash
pip install edge-tts
edge-tts --voice nb-NO-FinnNeural --text "Hei, dette er en test" --write-media /tmp/test.mp3
```
Norwegian voices: `nb-NO-FinnNeural` (male), `nb-NO-IselinNeural` (female).

## Support Files

- `templates/voice-input` — bash orchestrator for WSL bridge recording + transcription
- `templates/voice_transcribe.py` — Python Whisper transcription script (CUDA, Norwegian default)
- `references/wsl-setup-notes.md` — environment-specific setup notes, CUDA probe validation, venv location
- `references/norwegian-model-notes.md` — model comparison, download benchmarks, language code tips
