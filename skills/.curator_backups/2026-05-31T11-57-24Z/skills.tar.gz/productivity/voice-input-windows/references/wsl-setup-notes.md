# WSL Bridge Setup — Session Notes (2025-05-27, 2026-05-27)

## Environment
- WSL2 Ubuntu, RTX 4060, CUDA 13.2
- System Python 3.14+ locked (PEP 668 externally-managed-environment)
- Used `uv` (already installed at `~/.local/bin/uv`) for venv management

## Venv Location
- `/tmp/whisper-env/` — survives within session, recreate after reboot
- Create: `cd /tmp && uv venv whisper-env && source whisper-env/bin/activate && uv pip install faster-whisper`

## Model Choice
- `large-v3` — best Norwegian accuracy, loads on RTX 4060 (8GB VRAM)
- Load time ~15s first run, ~3s subsequent (CUDA context cached)
- User previously deployed scripts to `~/bin/voice_transcribe.py` and `~/bin/voice-input`

## CUDA Probe (validated)
```python
import numpy as np
from faster_whisper import WhisperModel
m = WhisperModel("large-v3", device="cuda", compute_type="float16")
audio = np.zeros(16000, dtype=np.float32)  # 1s silence
segs, _ = m.transcribe(audio, beam_size=1, vad_filter=False)
list(segs)  # forces CUDA init
```

## Norwegian Language
- Default `-l no` for voice input
- User communicates in English, voice input in Norwegian
- `large-v3` handles code-switching (Norwegian/English mix) reasonably well

## Mic Access in WSL
- WSL2 has NO direct mic access — needs PulseAudio bridge or Windows-side recording
- Test: `arecord -l` (ALSA) or `pactl list sources` (PulseAudio)
- Fallback: record via PowerShell dshow on Windows, transcribe in WSL

## TTS Status (2026-05-27)
- NeuTTS v0.1.2 installed but BROKEN — entire `neutts_samples/` dir missing
- NeuTTS requires a reference audio file of the user's voice for voice cloning
- The samples dir was never created (incomplete install, not a config issue)
- TTS is non-functional until reinstalled with voice sample, or switch to edge-tts/openai-tts
